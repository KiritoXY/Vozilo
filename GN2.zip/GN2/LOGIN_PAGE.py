# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'LOGIN_PAGE.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from SUCCESSFUL_LOGIN import *
from CREATE_NEW_ACCOUNT import *

class Ui_LOGIN_PAGE(object):
    def ok2(self):
        self.window=QtWidgets.QMainWindow()
        self.ui=Ui_CREATE_NEW_ACCOUNT1()
        self.ui.setup(self.window)
        self.window.show()
    def ok(self):
        self.window=QtWidgets.QMainWindow()
        self.ui=Ui_SUCCESSFUL_LOGIN1()
        self.ui.setup(self.window)
        self.window.show()
    def setupUi(self, LOGIN_PAGE):
        LOGIN_PAGE.setObjectName("LOGIN_PAGE")
        LOGIN_PAGE.resize(965, 617)
        self.centralwidget = QtWidgets.QWidget(LOGIN_PAGE)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.PHOTO = QtWidgets.QLabel(self.centralwidget)
        self.PHOTO.setText("")
        self.PHOTO.setPixmap(QtGui.QPixmap("Screenshot_2018-10-24 Employee.png"))
        self.PHOTO.setObjectName("PHOTO")
        self.verticalLayout_2.addWidget(self.PHOTO)
        self.WELCOME_GROUP_BOX = QtWidgets.QGroupBox(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(13)
        self.WELCOME_GROUP_BOX.setFont(font)
        self.WELCOME_GROUP_BOX.setObjectName("WELCOME_GROUP_BOX")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.WELCOME_GROUP_BOX)
        self.verticalLayout.setObjectName("verticalLayout")
        self.USERNAME_LABEL = QtWidgets.QLabel(self.WELCOME_GROUP_BOX)
        self.USERNAME_LABEL.setObjectName("USERNAME_LABEL")
        self.verticalLayout.addWidget(self.USERNAME_LABEL)
        self.USERNAME_LINE_EDIT = QtWidgets.QLineEdit(self.WELCOME_GROUP_BOX)
        self.USERNAME_LINE_EDIT.setObjectName("USERNAME_LINE_EDIT")
        self.verticalLayout.addWidget(self.USERNAME_LINE_EDIT)
        self.PASSWORD_LABEL = QtWidgets.QLabel(self.WELCOME_GROUP_BOX)
        self.PASSWORD_LABEL.setObjectName("PASSWORD_LABEL")
        self.verticalLayout.addWidget(self.PASSWORD_LABEL)
        self.PASSWORD_LINE_EDIT = QtWidgets.QLineEdit(self.WELCOME_GROUP_BOX)
        self.PASSWORD_LINE_EDIT.setObjectName("PASSWORD_LINE_EDIT")
        self.verticalLayout.addWidget(self.PASSWORD_LINE_EDIT)
        self.LOGIN_BUTTON = QtWidgets.QPushButton(self.WELCOME_GROUP_BOX)
        self.LOGIN_BUTTON.setObjectName("LOGIN_BUTTON")
        self.LOGIN_BUTTON.clicked.connect(self.ok)
        self.verticalLayout.addWidget(self.LOGIN_BUTTON)
        self.CREATE_ACCOUNT_BUTTON = QtWidgets.QPushButton(self.WELCOME_GROUP_BOX)
        self.CREATE_ACCOUNT_BUTTON.setObjectName("CREATE_ACCOUNT_BUTTON")
        self.CREATE_ACCOUNT_BUTTON.clicked.connect(self.ok2)
        self.verticalLayout.addWidget(self.CREATE_ACCOUNT_BUTTON)
        self.verticalLayout_2.addWidget(self.WELCOME_GROUP_BOX)
        LOGIN_PAGE.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(LOGIN_PAGE)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 965, 26))
        self.menubar.setObjectName("menubar")
        LOGIN_PAGE.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(LOGIN_PAGE)
        self.statusbar.setObjectName("statusbar")
        LOGIN_PAGE.setStatusBar(self.statusbar)

        self.retranslateUi(LOGIN_PAGE)
        QtCore.QMetaObject.connectSlotsByName(LOGIN_PAGE)

    def retranslateUi(self, LOGIN_PAGE):
        _translate = QtCore.QCoreApplication.translate
        LOGIN_PAGE.setWindowTitle(_translate("LOGIN_PAGE", "MainWindow"))
        self.WELCOME_GROUP_BOX.setTitle(_translate("LOGIN_PAGE", "WELCOME, SIGN-IN HERE"))
        self.USERNAME_LABEL.setText(_translate("LOGIN_PAGE", "USERNAME"))
        self.PASSWORD_LABEL.setText(_translate("LOGIN_PAGE", "PASSWORD"))
        self.LOGIN_BUTTON.setText(_translate("LOGIN_PAGE", "LOGIN!"))
        self.CREATE_ACCOUNT_BUTTON.setText(_translate("LOGIN_PAGE", "CREATE ACCOUNT"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    LOGIN_PAGE = QtWidgets.QMainWindow()
    ui = Ui_LOGIN_PAGE()
    ui.setupUi(LOGIN_PAGE)
    LOGIN_PAGE.show()
    sys.exit(app.exec_())

