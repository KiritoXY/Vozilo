from PIL import Image

def crop(image_path, coords, saved_location):

    image_obj = Image.open(image_path)

    cropped_image = image_obj.crop(coords)

    cropped_image.save(saved_location)

    cropped_image.show()

if __name__ == '__main__':

    image = 'grasshopper.jpg'

    crop('images.jpg', (122, 27, 225, 177), 'cropped.jpg')
