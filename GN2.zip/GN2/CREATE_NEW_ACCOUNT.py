# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'CREATE_NEW_ACCOUNT.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_CREATE_NEW_ACCOUNT1(object):
    def setup(self, CREATE_NEW_ACCOUNT):
        CREATE_NEW_ACCOUNT.setObjectName("CREATE_NEW_ACCOUNT")
        CREATE_NEW_ACCOUNT.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(CREATE_NEW_ACCOUNT)
        self.centralwidget.setObjectName("centralwidget")
        self.CREATE_ACCOUNT_GROUPBOX = QtWidgets.QGroupBox(self.centralwidget)
        self.CREATE_ACCOUNT_GROUPBOX.setGeometry(QtCore.QRect(90, 60, 601, 401))
        font = QtGui.QFont()
        font.setPointSize(13)
        self.CREATE_ACCOUNT_GROUPBOX.setFont(font)
        self.CREATE_ACCOUNT_GROUPBOX.setObjectName("CREATE_ACCOUNT_GROUPBOX")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.CREATE_ACCOUNT_GROUPBOX)
        self.verticalLayout.setObjectName("verticalLayout")
        self.USERNAME_LABEL = QtWidgets.QLabel(self.CREATE_ACCOUNT_GROUPBOX)
        self.USERNAME_LABEL.setObjectName("USERNAME_LABEL")
        self.verticalLayout.addWidget(self.USERNAME_LABEL)
        self.USERNAME_LINEEDIT = QtWidgets.QLineEdit(self.CREATE_ACCOUNT_GROUPBOX)
        self.USERNAME_LINEEDIT.setObjectName("USERNAME_LINEEDIT")
        self.verticalLayout.addWidget(self.USERNAME_LINEEDIT)
        self.PASSWORD_LABEL = QtWidgets.QLabel(self.CREATE_ACCOUNT_GROUPBOX)
        self.PASSWORD_LABEL.setObjectName("PASSWORD_LABEL")
        self.verticalLayout.addWidget(self.PASSWORD_LABEL)
        self.PASSWORD_LINEEDIT = QtWidgets.QLineEdit(self.CREATE_ACCOUNT_GROUPBOX)
        self.PASSWORD_LINEEDIT.setObjectName("PASSWORD_LINEEDIT")
        self.verticalLayout.addWidget(self.PASSWORD_LINEEDIT)
        self.ADMIN_PASSWORD_LABEL = QtWidgets.QLabel(self.CREATE_ACCOUNT_GROUPBOX)
        self.ADMIN_PASSWORD_LABEL.setObjectName("ADMIN_PASSWORD_LABEL")
        self.verticalLayout.addWidget(self.ADMIN_PASSWORD_LABEL)
        self.ADMIN_PASSWORD_LINEEDIT = QtWidgets.QLineEdit(self.CREATE_ACCOUNT_GROUPBOX)
        self.ADMIN_PASSWORD_LINEEDIT.setObjectName("ADMIN_PASSWORD_LINEEDIT")
        self.verticalLayout.addWidget(self.ADMIN_PASSWORD_LINEEDIT)
        self.CREATE_ACCOUNT_PUSHBUTTON = QtWidgets.QPushButton(self.CREATE_ACCOUNT_GROUPBOX)
        self.CREATE_ACCOUNT_PUSHBUTTON.setObjectName("CREATE_ACCOUNT_PUSHBUTTON")
        self.verticalLayout.addWidget(self.CREATE_ACCOUNT_PUSHBUTTON)
        self.CANCEL_PUSHBUTTON = QtWidgets.QPushButton(self.CREATE_ACCOUNT_GROUPBOX)
        self.CANCEL_PUSHBUTTON.setObjectName("CANCEL_PUSHBUTTON")
        self.verticalLayout.addWidget(self.CANCEL_PUSHBUTTON)
        CREATE_NEW_ACCOUNT.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(CREATE_NEW_ACCOUNT)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 26))
        self.menubar.setObjectName("menubar")
        CREATE_NEW_ACCOUNT.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(CREATE_NEW_ACCOUNT)
        self.statusbar.setObjectName("statusbar")
        CREATE_NEW_ACCOUNT.setStatusBar(self.statusbar)

        self.retranslateUi(CREATE_NEW_ACCOUNT)
        QtCore.QMetaObject.connectSlotsByName(CREATE_NEW_ACCOUNT)

    def retranslateUi(self, CREATE_NEW_ACCOUNT):
        _translate = QtCore.QCoreApplication.translate
        CREATE_NEW_ACCOUNT.setWindowTitle(_translate("CREATE_NEW_ACCOUNT", "MainWindow"))
        self.CREATE_ACCOUNT_GROUPBOX.setTitle(_translate("CREATE_NEW_ACCOUNT", "CREATE NEW ACCOUNT"))
        self.USERNAME_LABEL.setText(_translate("CREATE_NEW_ACCOUNT", "USERNAME"))
        self.PASSWORD_LABEL.setText(_translate("CREATE_NEW_ACCOUNT", "PASSWORD"))
        self.ADMIN_PASSWORD_LABEL.setText(_translate("CREATE_NEW_ACCOUNT", "ADMIN PASSWORD"))
        self.CREATE_ACCOUNT_PUSHBUTTON.setText(_translate("CREATE_NEW_ACCOUNT", "CREATE ACCOUNT"))
        self.CANCEL_PUSHBUTTON.setText(_translate("CREATE_NEW_ACCOUNT", "CANCEL"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    CREATE_NEW_ACCOUNT = QtWidgets.QMainWindow()
    ui = Ui_CREATE_NEW_ACCOUNT1()
    ui.setup(CREATE_NEW_ACCOUNT)
    CREATE_NEW_ACCOUNT.show()
    sys.exit(app.exec_())

