# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SUCCESSFUL_LOGIN.ui'
#
# Created by: PyQt5 UI code generator 5.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_SUCCESSFUL_LOGIN1(object):
    def setup(self, SUCCESSFUL_LOGIN):
        SUCCESSFUL_LOGIN.setObjectName("SUCCESSFUL_LOGIN")
        SUCCESSFUL_LOGIN.resize(817, 484)
        self.centralwidget = QtWidgets.QWidget(SUCCESSFUL_LOGIN)
        self.centralwidget.setObjectName("centralwidget")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(270, 70, 211, 146))
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.groupBox)
        self.verticalLayout.setObjectName("verticalLayout")
        self.ACCESS_RECORDS_BUTTON = QtWidgets.QPushButton(self.groupBox)
        font = QtGui.QFont()
        font.setPointSize(13)
        self.ACCESS_RECORDS_BUTTON.setFont(font)
        self.ACCESS_RECORDS_BUTTON.setObjectName("ACCESS_RECORDS_BUTTON")
        self.verticalLayout.addWidget(self.ACCESS_RECORDS_BUTTON)
        self.ADD_IMAGE_BUTTON = QtWidgets.QPushButton(self.groupBox)
        font = QtGui.QFont()
        font.setPointSize(13)
        self.ADD_IMAGE_BUTTON.setFont(font)
        self.ADD_IMAGE_BUTTON.setObjectName("ADD_IMAGE_BUTTON")
        self.verticalLayout.addWidget(self.ADD_IMAGE_BUTTON)
        self.EXIT_BUTTON = QtWidgets.QPushButton(self.groupBox)
        font = QtGui.QFont()
        font.setPointSize(13)
        self.EXIT_BUTTON.setFont(font)
        self.EXIT_BUTTON.setObjectName("EXIT_BUTTON")
        self.verticalLayout.addWidget(self.EXIT_BUTTON)
        SUCCESSFUL_LOGIN.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(SUCCESSFUL_LOGIN)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 817, 26))
        self.menubar.setObjectName("menubar")
        SUCCESSFUL_LOGIN.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(SUCCESSFUL_LOGIN)
        self.statusbar.setObjectName("statusbar")
        SUCCESSFUL_LOGIN.setStatusBar(self.statusbar)

        self.retranslateUi(SUCCESSFUL_LOGIN)
        QtCore.QMetaObject.connectSlotsByName(SUCCESSFUL_LOGIN)

    def retranslateUi(self, SUCCESSFUL_LOGIN):
        _translate = QtCore.QCoreApplication.translate
        SUCCESSFUL_LOGIN.setWindowTitle(_translate("SUCCESSFUL_LOGIN", "MainWindow"))
        self.ACCESS_RECORDS_BUTTON.setText(_translate("SUCCESSFUL_LOGIN", "ACCESS RECORDS"))
        self.ADD_IMAGE_BUTTON.setText(_translate("SUCCESSFUL_LOGIN", "ADD IMAGE"))
        self.EXIT_BUTTON.setText(_translate("SUCCESSFUL_LOGIN", "EXIT"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    SUCCESSFUL_LOGIN = QtWidgets.QMainWindow()
    ui = Ui_SUCCESSFUL_LOGIN1()
    ui.setup(SUCCESSFUL_LOGIN)
    SUCCESSFUL_LOGIN.show()
    sys.exit(app.exec_())

